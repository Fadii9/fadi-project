let allData = {
customers:[
    {
        name: "Customer1",
        order: ["Hamburger", "Salad"]
    },

    {
        name: "Customer2",
        order: ["Salad"]
    },

    {
        name: "Customer3",
        order: ["Steak"]
    },

    {
        name: "Customer4",
        order: ["Pizza", "Hamburger"]
    },

    {
        name: "Customer5",
        order: ["spaghetti", "Pizza"]
    },

    {
        name: "Customer6",
        order: ["Salad", "Pizza"]
    },

    {
        name: "Customer7",
        order: ["spaghetti", "Pizza", "Hamburger"]
    },

    {
        name: "Customer8",
        order: ["spaghetti", "Pizza", "Steak"]
    },

    {
        name: "Customer9",
        order: ["Baguette"]
    },

    {
        name: "Customer10",
        order: ["spaghetti", "Salad"]
    },
    {
        name: "Customer11",
        order: ["Hamburger", "Salad"]
    },

    {
        name: "Customer12",
        order: ["Salad"]
    },

    {
        name: "Customer13",
        order: ["Steak"]
    },

    {
        name: "Customer14",
        order: ["Pizza", "Hamburger"]
    },

    {
        name: "Customer15",
        order: ["spaghetti", "Pizza"]
    },

    {
        name: "Customer16",
        order: ["Salad", "Pizza"]
    },

    {
        name: "Customer17",
        order: ["spaghetti", "Pizza", "Hamburger"]
    },

    {
        name: "Customer18",
        order: ["spaghetti", "Pizza", "Steak"]
    },

    {
        name: "Customer19",
        order: ["Baguette"]
    },

    {
        name: "Customer20",
        order: ["spaghetti", "Salad"]
    },

],


meals : [{
    mealName: "Hamburger",
    ingredients: ["Bread", "Patty", "Tomato", "pickles", "Lettuce", "onions"]
}, {
    mealName: "Salad",
    ingredients: ["Tomato", "Cucumber", "Lettuce", "onions"]
}, {
    mealName: "Steak",
    ingredients: ["meat"]
}, {
    mealName: "Pizza",
    ingredients: ["Dough", "Tomato-sauce", "cheese"]
}, {
    mealName: "Spaghetti",
    ingredients: ["Spaghetti", "Tomato-sauce"]
}, {
    mealName: "Baguette",
    ingredients: ["Dough"]
}],


ingredients: [
    {
        ing: "Bread",
        amount: 50,
        prepTime: 1000
    },
    {
        ing: "Patty",
        amount: 50,
        prepTime: 8000
    },

    {
        ing: "Tomato",
        amount: 50,
        prepTime: 1000
    },

    {
        ing: "pickles",
        amount: 50,
        prepTime: 1000
    },

    {
        ing: "Lettuce",
        amount: 50,
        prepTime: 1000
    },

    {
        ing: "Cucumber",
        amount: 50,
        prepTime: 1000
    },

    {
        ing: "onions",
        amount: 50,
        prepTime: 1000
    },

    {
        ing: "meat",
        amount: 50,
        prepTime: 10000
    },

    {
        ing: "Dough",
        amount: 50,
        prepTime: 1000
    },

    {
        ing: "Tomato-sauce",
        amount: 50,
        prepTime: 3000
    },

    {
        ing: "Cheese",
        amount: 50,
        prepTime: 2000
    },

    {
        ing: "Spaghetti",
        amount: 50,
        prepTime: 10000
    }
]

}

export default allData